import os
import boto3
from botocore.client import Config

# 1. Configuração do Cliente S3 compatível com o MinIO local
s3 = boto3.client(
    's3',
    endpoint_url='http://localhost:9000',
    aws_access_key_id='minioadmin',
    aws_secret_access_key='minioadmin',
    config=Config(signature_version='s3v4'),
    region_name='us-east-1'
)

bucket_name = 'meu-novo-bucket'
arquivo_local = 'localfile.txt'
arquivo_baixado = 'baixado_localfile.txt'

# 2. Criar um arquivo local simples para teste
with open(arquivo_local, 'w') as f:
    f.write('Ola Mundo! Este e um teste de Object Storage no MinIO.')
print(f"[*] Arquivo local '{arquivo_local}' criado.")

# 3. Criar o Bucket (se não existir)
try:
    s3.create_bucket(Bucket=bucket_name)
    print(f"[*] Bucket '{bucket_name}' criado com sucesso.")
except Exception as e:
    print(f"[-] O bucket ja existe ou ocorreu um erro: {e}")

# 4. Operação PUT: Upload do arquivo
s3.upload_file(arquivo_local, bucket_name, arquivo_local)
print(f"[+] Upload de '{arquivo_local}' realizado com sucesso.")

# 5. Operação LIST: Listar objetos no bucket
print("[*] Listando objetos no bucket:")
response = s3.list_objects_v2(Bucket=bucket_name)
for obj in response.get('Contents', []):
    print(f"  - Chave (Key): {obj['Key']} | Tamanho: {obj['Size']} bytes")

# 6. Gerar Presigned URL (URL Temporária)
url = s3.generate_presigned_url(
    'get_object',
    Params={'Bucket': bucket_name, 'Key': arquivo_local},
    ExpiresIn=3600  # 1 hora
)
print(f"[+] URL temporaria gerada com sucesso:\n{url}")

# 7. Operação GET: Download do arquivo
s3.download_file(bucket_name, arquivo_local, arquivo_baixado)
print(f"[+] Download realizado. Arquivo salvo como '{arquivo_baixado}'.")